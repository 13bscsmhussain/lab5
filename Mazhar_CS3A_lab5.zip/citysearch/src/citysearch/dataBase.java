package citysearch;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mhussain.bscs13seecs
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dataBase {
    
    public dataBase ()
    {
    }
 
    
    public Connection connect(String db_connect_str, 
  String db_userid, String db_password)
    {
        Connection conn;
        try
        {
            Class.forName(  
    "com.mysql.jdbc.Driver").newInstance();
 
            conn = DriverManager.getConnection(db_connect_str, 
    db_userid, db_password);
         
        }
        catch(Exception e)
        {
            e.printStackTrace();
            conn = null;
        }
 
        return conn;    
    }
     
    public void importData(Connection conn,String filename)
    {
        Statement stmt;
        String query;
 
        try
        {
            stmt = conn.createStatement(
    ResultSet.TYPE_SCROLL_SENSITIVE,
    ResultSet.CONCUR_UPDATABLE);
           //query = "create database if not exists geoCity; use geoCity; create table if not exists Geo_City_Lite(locId INT AUTO_INCREMENT PRIMARY KEY,country varchar(150),region varchar(150),city varchar(150),postalCode  varchar(150),latitude DECIMAL(12,9),longitude DECIMAL(12,9),metroCode bigint ,areaCode bigint);";
           query = "LOAD DATA INFILE '"+filename+"' INTO TABLE  citiesinfo  FIELDS TERMINATED BY ',' (locId,country,region,city,postalCode,latitude,longitude,metroCode,areaCode)";
   
            stmt.executeUpdate(query);
                 
        }
        catch(Exception e)
        {
            e.printStackTrace();
            stmt = null;
        }
    }
    
    
}
