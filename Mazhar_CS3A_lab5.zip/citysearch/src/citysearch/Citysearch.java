/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citysearch;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*; 
import java.text.ParseException; 
import java.text.SimpleDateFormat; 
import java.io.*; 
import java.lang.String; 
import java.util.Scanner; 

/**
 *
 * @author mhussain.bscs13seecs
 */
public class Citysearch {

     // JDBC driver name and database URL
   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost/";
   static final String DB_URL1 = "jdbc:mysql://localhost/geolitecity";
   //  Database credentials
   static final String USER = "root";
   static final String PASS = "root";
    
    /**
     * @param args the command line arguments
     */
    public Citysearch()
    {
    }
    
   public static void checkDatabase(){
       
      Connection conn = null;
   Statement stmt = null;
   try{
      //STEP 2: Register JDBC driver
      Class.forName("com.mysql.jdbc.Driver");

      //STEP 3: Open a connection
      System.out.println("Connecting to database...");
      conn = DriverManager.getConnection(DB_URL, USER, PASS);

      //STEP 4: Execute a query
      System.out.println("Creating database...");
      stmt = conn.createStatement();
      
      String sql = "CREATE DATABASE if not exists geolitecity";
      stmt.executeUpdate(sql);
      System.out.println("Database created successfully...");
      
      
      
      
      
      System.out.println("Connecting to a selected database...");
      conn = DriverManager.getConnection(DB_URL1, USER, PASS);
      System.out.println("Connected database successfully...");
      
      //STEP 4: Execute a query
      System.out.println("Creating table in given database...");
      stmt = conn.createStatement();
      
      String sql1 = "CREATE TABLE if not exists citiesinfo " +
                   "(locId INTEGER not NULL, " +
                   " country VARCHAR(125), " + 
                   " region VARCHAR(125), " + 
                   " city VARCHAR(125), " + 
                    " postalCode VARCHAR(125), " +
                     " latitude float, " + 
               " longitude float, " + 
               " metroCode int, " + 
               " areacode int, " + 
                   " PRIMARY KEY ( locId ))"; 

      stmt.executeUpdate(sql1);
      System.out.println("Created table in given database...");
   }catch(SQLException se){
      //Handle errors for JDBC
      se.printStackTrace();
   }catch(Exception e){
      //Handle errors for Class.forName
      e.printStackTrace();
   }finally{
      //finally block used to close resources
      try{
         if(stmt!=null)
            stmt.close();
      }catch(SQLException se2){
      }// nothing we can do
      try{
         if(conn!=null)
            conn.close();
      }catch(SQLException se){
         se.printStackTrace();
      }//end finally try
   }//end try
   System.out.println("Goodbye!");
}//end main
  
       
   
    
   
    //import mysql-connector-java-5.1.32.jar 
   public static void main(String[] args) {
   
       Citysearch.checkDatabase();
       
       dataBase  db = new dataBase ();
        Connection conn2 = db.connect("jdbc:mysql://localhost:3306/geolitecity","root","root");
        db.importData(conn2,"data.csv");

   } 
}
    

