/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package citysearch;

import java.sql.Connection;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author mhussain.bscs13seecs
 */
public class dataBaseTest {
    
    public dataBaseTest() {
    }

    /**
     * Test of connect method, of class dataBase.
     */
    @Test
    public void testConnect() {
        System.out.println("connect");
        String db_connect_str = "";
        String db_userid = "root";
        String db_password = "root";
        dataBase instance = new dataBase();
        Connection expResult = null;
        Connection result = instance.connect(db_connect_str, db_userid, db_password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of importData method, of class dataBase.
     */
    @Test
    public void testImportData() {
        System.out.println("importData");
        Connection conn = null;
        String filename = "data.csv";
        dataBase instance = new dataBase();
        instance.importData(conn, filename);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
